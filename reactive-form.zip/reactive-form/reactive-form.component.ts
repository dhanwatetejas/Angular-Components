import { Component } from '@angular/core';
import { FormGroup,FormControl } from '@angular/forms';
import { Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-reactive-form',
  templateUrl: './reactive-form.component.html',
  styleUrl: './reactive-form.component.css'
})
export class ReactiveFormComponent {
  
 loginForm= new FormGroup({
   name: new FormControl('',Validators.required),
   phone:new FormControl('',Validators.required),
   password:new FormControl('',Validators.required),
   qualification:new FormControl('',Validators.required)

 })
 

constructor(private router:Router) {

}
 reactiveDetail(){
   console.log(this.loginForm.value);
   this.router.navigate(['Registered'])

   
 }
}
