import { Component } from '@angular/core';
import { FormGroup,FormControl,Validator, Validators } from '@angular/forms';

@Component({
  selector: 'app-form1',
  templateUrl: './form1.component.html',
  styleUrl: './form1.component.css'
})
export class Form1Component {
  loginForm =new FormGroup({
   firstName:new FormControl('',[Validators.required]),
   lastName:new FormControl('',[Validators.required]),
   password:new FormControl('',[Validators.required,Validators.minLength(8),Validators.maxLength(15)]),
   phone:new FormControl('',[Validators.required,Validators.maxLength(10)]),
   address:new FormControl('',Validators.required), 
   qualification:new FormControl('',Validators.required)
  })
  saveForm(){
    console.log(this.loginForm.value);
    
  }
  get firstName(){
    return this.loginForm.get('firstName')
  }
  get lastName(){
    return this.loginForm.get('lastName')
  }
  get password(){
    return this.loginForm.get('password')
  }
  get phone(){
    return this.loginForm.get('phone')
  }
  get address(){
    return this.loginForm.get('address')
  }
  get qualification(){
    return this.loginForm.get('qualification')
  }

}
