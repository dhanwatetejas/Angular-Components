import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-template2',
  standalone: true,
  imports: [FormsModule],
  templateUrl: './template2.component.html',
  styleUrl: './template2.component.css'
})
export class Template2Component {
  firstName:any;
  lastName:any;
  middleName:any;
  phone:any;
  address:any;
  qualification:any;

  getDetails(item:any){
    console.log(item);
    
  }

}
