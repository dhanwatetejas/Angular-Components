import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';

@Component({
  selector: 'app-bootstraping',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './bootstraping.component.html',
  styleUrl: './bootstraping.component.css'
})
export class BootstrapingComponent {

}
