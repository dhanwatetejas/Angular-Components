import { CommonModule } from '@angular/common';
import { Component,Input } from '@angular/core';

@Component({
  selector: 'app-todo',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './todo.component.html',
  styleUrl: './todo.component.css'
})
export class TodoComponent {
  @Input()
  data: {id:any,name:any}={id:"",name:""};
list:any[]=[];


addTask(item:string){
  this.list.push({Id:this.list.length,Task:item});
  console.log(this.list);
 
  }
removeTask(id:number){

this.list=this.list.filter(item=>item.Id!==id);
}

}
